from PIL import Image, ImageStat
import glob 
import numpy as np
import seaborn as sns

from utils import check_results

import matplotlib.pyplot as plt

def calculate_mean_std(image_list):
    """
    calculate mean and std of image list
    args:
    - image_list [list[str]]: list of image paths
    returns:
    - mean [array]: 1x3 array of float, channel wise mean
    - std [array]: 1x3 array of float, channel wise std
    """
    # IMPLEMENT THIS FUNCTION
    means = [ np.array(ImageStat.Stat(Image.open(path).convert("RGB")).mean) for path in image_list ]
    stds = [ np.array(ImageStat.Stat(Image.open(path).convert("RGB")).stddev) for path in image_list ] 
    
    mean = np.mean(means, axis=0)
    std = np.mean(stds, axis=0)
    
    return mean, std


def channel_histogram(image_list):
    """
    calculate channel wise pixel value
    args:
    - image_list [list[str]]: list of image paths
    """
    red = np.array([ np.array(Image.open(path).convert('RGB'))[...,0] for path in image_list]).flatten().tolist()
    green = np.array([ np.array(Image.open(path).convert('RGB'))[...,1] for path in image_list]).flatten().tolist()
    blue = np.array([ np.array(Image.open(path).convert('RGB'))[...,2] for path in image_list ]).flatten().tolist()
    
 
    
    plt.figure()
    sns.kdeplot(red, color='r')
    sns.kdeplot(green, color='g')
    sns.kdeplot(blue, color='b')
    plt.show()
    
    
    # IMPLEMENT THIS FUNCTION


if __name__ == "__main__": 
    image_list = glob.glob('data/images/*')
    means, stds = calculate_mean_std(image_list)
    
    check_results(means, stds)