from utils import get_data
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from PIL import Image
from enum import Enum
from os import walk 

path_to_images = "./data/images/"

colors = {
    1: "r",
    2: "g"
}


def viz(ground_truth):
    """
    create a grid visualization of images with color coded bboxes
    args:
    - ground_truth [list[dict]]: ground truth data
    """
    # IMPLEMENT THIS FUNCTION
    samples = { gt["filename"]:gt for gt in ground_truth }
    
    print(colors[1])
    short_path_filenames = next(walk(path_to_images), (None,None, []))[2]
    full_path_filenames = [ path_to_images + filename for filename in short_path_filenames ] 
    
    fig, ax = plt.subplots(4,5, figsize=(20, 10))
    
    for idx in range(20):
        x = idx % 4
        y = idx % 5
        
        img = Image.open(full_path_filenames[idx])
        ax[x, y].imshow(img)
        
        bboxes = samples[short_path_filenames[idx]]["boxes"]
        classes = samples[short_path_filenames[idx]]["classes"]
        
        for box_coordinates, _class in zip(bboxes, classes):
            y1, x1, y2, x2 = box_coordinates
            
            x_len = x2 - x1
            y_len = y2 - y1
            bounding_box = patches.Rectangle((x1, y1), x_len, y_len, linewidth=1, edgecolor=colors[_class], facecolor="none")
            
            ax[x,y].add_patch(bounding_box)
                       
                
    plt.tight_layout()
    plt.show()
        

if __name__ == "__main__": 
    ground_truth, _ = get_data()
    viz(ground_truth)